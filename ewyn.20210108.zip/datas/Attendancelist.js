module.exports = [
  {
    customerid: 1,
    date: "2020-01-07",
    weight: 100,
    gainLoss: -23, // current weight - last weight
    cardio: "Exercise3",
    comment: "abcdef...",
    dtr: "2020-01-14"
  },
  {
    customerid: 1,
    date: "2020-01-01",
    weight: 123,
    gainLoss: 12, // current weight - last weight
    cardio: "Exercise2",
    comment: "xyz...",
    dtr: "2020-01-07"
  },
  {
    customerid: 2,
    date: "2019-12-12",
    weight: 123,
    gainLoss: -23, // current weight - last weight
    cardio: "Exercise1",
    comment: "uvwxyz...",
    dtr: "2019-12-31"
  }
];
