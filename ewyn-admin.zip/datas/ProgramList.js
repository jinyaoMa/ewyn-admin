module.exports = [
  {
    programid: 1,
    program_name: "Phase 1"
  },
  {
    programid: 2,
    program_name: "Phase 1 + Protein"
  },
  {
    programid: 3,
    program_name: "Stabilization (1,2,3)"
  },
  {
    programid: 4,
    program_name: "Active"
  },
  {
    programid: 5,
    program_name: "Maintenance"
  }
];
