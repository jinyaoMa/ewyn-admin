#!/usr/bin/env sh

npm install
npm run front:build
npm run back:prod
