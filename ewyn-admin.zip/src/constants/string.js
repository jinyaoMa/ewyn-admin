const server_base = `${process.env.VUE_APP_ORIGIN}:${process.env.VUE_APP_SERVER_PORT}/api/`;

export default {
  server_base
};
