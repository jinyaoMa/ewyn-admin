import logo from "../assets/Ewyn-Weight-Loss-Logo-Yellow-No-Outline-01.png";
import header_bg from "../assets/header-bg.jpg";

export default {
  logo,
  header_bg
};
